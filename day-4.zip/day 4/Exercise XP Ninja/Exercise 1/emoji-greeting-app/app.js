const express = require('express');
const bodyParser = require('body-parser');
const greetingRoutes = require('./routes/greeting');

const app = express();
const PORT = 3000;

// Set up middleware
app.use(bodyParser.urlencoded({ extended: false }));

// Mount routes
app.use('/', greetingRoutes);

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
