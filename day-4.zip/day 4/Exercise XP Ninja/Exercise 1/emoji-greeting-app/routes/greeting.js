const express = require('express');
const router = express.Router();

// List of available emojis
const emojis = ["😀", "🎉", "🌟", "🎈", "👋"];

// GET route to display the form
router.get('/', (req, res) => {
    let emojiOptions = emojis.map(emoji => `<option value="${emoji}">${emoji}</option>`).join('');
    res.send(`
        <form action="/greet" method="post">
            Name: <input type="text" name="name" required>
            Emoji: <select name="emoji">${emojiOptions}</select>
            <input type="submit" value="Greet">
        </form>
    `);
});

// POST route to process form and display greeting
router.post('/greet', (req, res) => {
    const { name, emoji } = req.body;
    res.send(`
        <h1>Hello ${name} ${emoji}</h1>
        <a href="/">Go back</a>
    `);
});

module.exports = router;
